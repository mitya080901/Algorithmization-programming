using System;
using System.Linq;

class Program
{
    static void Main()
    {
        //6.1
        Console.Write("n = ");
        int n1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(Factorial(n1));
        static long Factorial(int n)
        {
            if (n == 0) return 1;
            return n * Factorial(n - 1);
        }

        //6.2
        Console.Write("n = ");
        int n2 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(Fib(n2));
        static int Fib(int n)
        {
            if (n <= 1) return n;
            return Fib(n - 1) + Fib(n - 2);
        }

        //6.3
        Console.Write("�����: ");
        int num = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(SumDigits(num));
        static int SumDigits(int n)
        {
            if (n == 0) return 0;
            return (n % 10) + SumDigits(n / 10);
        }

        //6.4
        Console.Write("���������: ");
        double baseNum = Convert.ToDouble(Console.ReadLine());
        Console.Write("�������: ");
        int exp = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(Pow(baseNum, exp));
        static double Pow(double b, int e)
        {
            if (e == 0) return 1;
            if (e < 0) return 1 / Pow(b, -e);
            return b * Pow(b, e - 1);
        }

        //6.5
        Console.Write("a = ");
        int a5 = Convert.ToInt32(Console.ReadLine());
        Console.Write("b = ");
        int b5 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(GCD(a5, b5));
        static int GCD(int a, int b)
        {
            if (b == 0) return a;
            return GCD(b, a % b);
        }

        //6.6
        Console.Write("������: ");
        string s6 = Console.ReadLine();
        Console.WriteLine(ReverseString(s6));
        static string ReverseString(string s)
        {
            if (s.Length <= 1) return s;
            return s[s.Length - 1] + ReverseString(s.Substring(0, s.Length - 1));
        }

        //6.7
        int[] arr = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };
        Console.Write("����: ");
        int target = Convert.ToInt32(Console.ReadLine());
        int res = BinarySearch(arr, target, 0, arr.Length - 1);
        Console.WriteLine(res >= 0 ? $"������ �� ������� {res}" : "�� ������");
        static int BinarySearch(int[] arr, int x, int low, int high)
        {
            if (low > high) return -1;
            int mid = (low + high) / 2;
            if (arr[mid] == x) return mid;
            if (arr[mid] > x) return BinarySearch(arr, x, low, mid - 1);
            return BinarySearch(arr, x, mid + 1, high);
        }

        //6.8
        int[] arr8 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        Console.WriteLine(SumArray(arr8, arr8.Length - 1));
        static int SumArray(int[] arr, int index)
        {
            if (index < 0) return 0;
            return arr[index] + SumArray(arr, index - 1);
        }

        //6.9
        Console.Write("���-�� ������: ");
        int disks = Convert.ToInt32(Console.ReadLine());
        Hanoi(disks, 'A', 'C', 'B');
        static void Hanoi(int n, char from, char to, char aux)
        {
            if (n == 1)
            {
                Console.WriteLine($"����������� ���� 1 � {from} �� {to}");
                return;
            }
            Hanoi(n - 1, from, aux, to);
            Console.WriteLine($"����������� ���� {n} � {from} �� {to}");
            Hanoi(n - 1, aux, to, from);
        }

        //6.10
        Console.Write("������: ");
        string s10 = Console.ReadLine();
        Console.WriteLine(IsPalindrome(s10, 0, s10.Length - 1) ? "���������" : "�� ���������");
        static bool IsPalindrome(string s, int left, int right)
        {
            if (left >= right) return true;
            if (char.ToLower(s[left]) != char.ToLower(s[right])) return false;
            return IsPalindrome(s, left + 1, right - 1);
        }
    }
}

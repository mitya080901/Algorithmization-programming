//9.1
using System;
using System.IO;

class Program
{
    static void Main()
    {
        using (StreamWriter sw = new StreamWriter("text.txt"))
        {
            sw.WriteLine("������, ���!");
            sw.WriteLine("��� �������� ������.");
        }
    }
}

//9.2
using System;
using System.IO;

class Program
{
    static void Main()
    {
        using (StreamReader sr = new StreamReader("text.txt"))
        {
            string content = sr.ReadToEnd();
            Console.WriteLine(content);
        }
    }
}

//9.3
using System;
using System.IO;

class Program
{
    static void Main()
    {
        using (StreamReader sr = new StreamReader("text.txt"))
        {
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                Console.WriteLine(line);
            }
        }
    }
}

//9.4
using System;
using System.IO;

class Program
{
    static int CountLines(string path)
    {
        int count = 0;
        using (StreamReader sr = new StreamReader(path))
        {
            while (sr.ReadLine() != null) count++;
        }
        return count;
    }
}

//9.5
using System;
using System.IO;

class Program
{
    static void Main()
    {
        using (StreamWriter sw = new StreamWriter("text.txt", true))
        {
            sw.WriteLine("����� ������ ��������� � ����� �����");
        }
    }
}

//9.6
using System;
using System.IO;

class Program
{
    static void Main()
    {
        if (File.Exists("source.txt"))
        {
            File.Copy("source.txt", "copy.txt", true);
            Console.WriteLine("���� ����������");
        }
    }
}

//9.7
using System;
using System.IO;

class Program
{
    static bool ContainsWord(string path, string word)
    {
        using (StreamReader sr = new StreamReader(path))
        {
            string content = sr.ReadToEnd();
            return content.Contains(word);
        }
    }
}

//9.8
using System;
using System.IO;

class Program
{
    static void Main()
    {
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        using (StreamWriter sw = new StreamWriter("numbers.txt"))
        {
            foreach (int n in numbers)
                sw.WriteLine(n);
        }
    }
}

//9.9
using System;
using System.IO;

class Program
{
    static int[] ReadNumbers(string path)
    {
        string[] lines = File.ReadAllLines(path);
        int[] result = new int[lines.Length];
        for (int i = 0; i < lines.Length; i++)
            int.TryParse(lines[i], out result[i]);
        return result;
    }
}

//9.10
using System;
using System.IO;

class Program
{
    static (int lines, int words, int chars) GetFileStats(string path)
    {
        string content = File.ReadAllText(path);
        int lines = content.Split('\n').Length;
        int words = content.Split(new char[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
        int chars = content.Length;
        return (lines, words, chars);
    }
}
//7.1
using System;
class Program
{
    static void SelectionSort(int[] arr)
    {
        for (int i = 0; i < arr.Length - 1; i++)
        {
            int min = i;
            for (int j = i + 1; j < arr.Length; j++)
                if (arr[j] < arr[min]) min = j;
            int temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }
}

//7.2
using System;
class Program
{
    static void InsertionSort(int[] arr)
    {
        for (int i = 1; i < arr.Length; i++)
        {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key)
            {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }
}

//7.3
using System;
class Program
{
    static void QuickSort(int[] arr, int low, int high)
    {
        if (low < high)
        {
            int pi = Partition(arr, low, high);
            QuickSort(arr, low, pi - 1);
            QuickSort(arr, pi + 1, high);
        }
    }
    static int Partition(int[] arr, int low, int high)
    {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++)
        {
            if (arr[j] <= pivot)
            {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp1 = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp1;
        return i + 1;
    }
}

//7.4
using System;
class Program
{
    static void MergeSort(int[] arr, int l, int r)
    {
        if (l < r)
        {
            int m = l + (r - l) / 2;
            MergeSort(arr, l, m);
            MergeSort(arr, m + 1, r);
            Merge(arr, l, m, r);
        }
    }
    static void Merge(int[] arr, int l, int m, int r)
    {
        int n1 = m - l + 1;
        int n2 = r - m;
        int[] L = new int[n1];
        int[] R = new int[n2];
        Array.Copy(arr, l, L, 0, n1);
        Array.Copy(arr, m + 1, R, 0, n2);
        int i = 0, j = 0, k = l;
        while (i < n1 && j < n2)
            arr[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }
}

//7.5
using System;
class Program
{
    static int LinearSearch(int[] arr, int x)
    {
        for (int i = 0; i < arr.Length; i++)
            if (arr[i] == x) return i;
        return -1;
    }
}

//7.6
using System;
class Program
{
    static int BinarySearch(int[] arr, int x)
    {
        int l = 0, r = arr.Length - 1;
        while (l <= r)
        {
            int m = l + (r - l) / 2;
            if (arr[m] == x) return m;
            if (arr[m] < x) l = m + 1;
            else r = m - 1;
        }
        return -1;
    }
}

//7.7
using System;
class Program
{
    static (int min, int max) FindMinMax(int[] arr)
    {
        int min = arr[0], max = arr[0];
        for (int i = 1; i < arr.Length; i++)
        {
            if (arr[i] < min) min = arr[i];
            if (arr[i] > max) max = arr[i];
        }
        return (min, max);
    }
}

//7.8
using System;
class Program
{
    static bool IsPrime(int n)
    {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        for (int i = 3; i * i <= n; i += 2)
            if (n % i == 0) return false;
        return true;
    }
}

//7.9
using System;
class Program
{
    static bool IsAnagram(string s1, string s2)
    {
        if (s1.Length != s2.Length) return false;
        char[] c1 = s1.ToCharArray();
        char[] c2 = s2.ToCharArray();
        Array.Sort(c1);
        Array.Sort(c2);
        return new string(c1) == new string(c2);
    }
}

//7.10
using System;
class Program
{
    static int LongestSubsequence(int[] arr)
    {
        int maxLen = 1, currentLen = 1;
        for (int i = 1; i < arr.Length; i++)
        {
            if (arr[i] > arr[i - 1])
                currentLen++;
            else
                currentLen = 1;
            maxLen = Math.Max(maxLen, currentLen);
        }
        return maxLen;
    }
}

//7.11
using System;
using System.Collections.Generic;
class Program
{
    static List<int> FindDuplicates(int[] arr)
    {
        Dictionary<int, int> count = new Dictionary<int, int>();
        List<int> duplicates = new List<int>();
        foreach (int num in arr)
        {
            if (count.ContainsKey(num))
            {
                if (count[num] == 1)
                    duplicates.Add(num);
                count[num]++;
            }
            else
                count[num] = 1;
        }
        return duplicates;
    }
}
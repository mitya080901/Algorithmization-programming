//8.1
using System;

class Student
{
    public string Name { get; set; }
    public int Age { get; set; }
    public double Grade { get; set; }

    public Student(string name, int age, double grade)
    {
        Name = name;
        Age = age;
        Grade = grade;
    }

    public void PrintInfo()
    {
        Console.WriteLine($"���: {Name}, �������: {Age}, ������: {Grade}");
    }
}

//8.2
using System;

class BankAccount
{
    private string accountNumber;
    private double balance;

    public BankAccount(string accountNumber, double initialBalance)
    {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    public void Deposit(double amount)
    {
        if (amount > 0) balance += amount;
    }

    public bool Withdraw(double amount)
    {
        if (amount > 0 && balance >= amount)
        {
            balance -= amount;
            return true;
        }
        return false;
    }

    public double GetBalance() => balance;
    public string GetAccountNumber() => accountNumber;
}

//8.3
using System;

class Animal
{
    public virtual void MakeSound()
    {
        Console.WriteLine("�������� ����� ����");
    }
}

class Dog : Animal
{
    public override void MakeSound()
    {
        Console.WriteLine("���-���!");
    }
}

class Cat : Animal
{
    public override void MakeSound()
    {
        Console.WriteLine("���!");
    }
}

//8.4
using System;

class Rectangle
{
    public double Width { get; set; }
    public double Height { get; set; }

    public Rectangle()
    {
        Width = 1.0;
        Height = 1.0;
    }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public double GetArea() => Width * Height;
    public double GetPerimeter() => 2 * (Width + Height);
}

//8.5
using System;

class MathHelper
{
    public static int Count { get; private set; } = 0;

    public static double PI => 3.1415926535;

    public static int Add(int a, int b)
    {
        Count++;
        return a + b;
    }

    public static double Multiply(double a, double b)
    {
        Count++;
        return a * b;
    }
}

//8.6
using System;

abstract class Shape
{
    public abstract double GetArea();
    public abstract double GetPerimeter();
}

class Circle : Shape
{
    public double Radius { get; set; }

    public Circle(double radius) => Radius = radius;

    public override double GetArea() => Math.PI * Radius * Radius;
    public override double GetPerimeter() => 2 * Math.PI * Radius;
}

class Triangle : Shape
{
    public double A { get; set; }
    public double B { get; set; }
    public double C { get; set; }

    public Triangle(double a, double b, double c)
    {
        A = a; B = b; C = c;
    }

    public override double GetArea()
    {
        double p = (A + B + C) / 2;
        return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
    }

    public override double GetPerimeter() => A + B + C;
}

//8.7
using System;
using System.Collections.Generic;

class Person : IComparable<Person>
{
    public string Name { get; set; }
    public int Age { get; set; }

    public int CompareTo(Person other)
    {
        return Age.CompareTo(other.Age);
    }
}

//8.8
using System;

class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
    public int Year { get; set; }
    private int pages;

    public int Pages
    {
        get => pages;
        set
        {
            if (value > 0) pages = value;
            else throw new ArgumentException("���������� ������� ������ ���� �������������");
        }
    }
}

//8.9
using System;

struct Complex
{
    public double Real { get; set; }
    public double Imag { get; set; }

    public Complex(double real, double imag)
    {
        Real = real;
        Imag = imag;
    }

    public static Complex operator +(Complex a, Complex b)
    {
        return new Complex(a.Real + b.Real, a.Imag + b.Imag);
    }

    public static Complex operator -(Complex a, Complex b)
    {
        return new Complex(a.Real - b.Real, a.Imag - b.Imag);
    }

    public override string ToString() => $"{Real} + {Imag}i";
}

//8.10
using System;

class Engine
{
    public double Volume { get; set; }
    public void Start() => Console.WriteLine("��������� �������");
}

class Wheel
{
    public double Diameter { get; set; }
}

class Car
{
    private Engine engine;
    private Wheel[] wheels;

    public Car()
    {
        engine = new Engine { Volume = 2.0 };
        wheels = new Wheel[4];
        for (int i = 0; i < 4; i++)
            wheels[i] = new Wheel { Diameter = 17.5 };
    }

    public void Start() => engine.Start();
}

//8.11
using System;

class ShoppingList
{
    private string[] items = new string[100];
    private int count = 0;

    public string this[int index]
    {
        get
        {
            if (index >= 0 && index < count) return items[index];
            throw new IndexOutOfRangeException();
        }
        set
        {
            if (index >= 0 && index < count) items[index] = value;
            else if (index == count) items[count++] = value;
            else throw new IndexOutOfRangeException();
        }
    }

    public int Count => count;
}

//8.12
using System;

class SafeDivider
{
    public double Divide(string a, string b)
    {
        try
        {
            double x = double.Parse(a);
            double y = double.Parse(b);
            if (y == 0) throw new DivideByZeroException();
            return x / y;
        }
        catch (FormatException)
        {
            Console.WriteLine("������: ������� �� �����");
            return double.NaN;
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("������: ������� �� ����");
            return double.NaN;
        }
    }
}
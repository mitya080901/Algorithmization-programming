using System;
using System.Linq;

class Program
{
    static void Main()
    {
        //5.1
        Console.Write("a = "); int a1 = int.Parse(Console.ReadLine());
        Console.Write("b = "); int b1 = int.Parse(Console.ReadLine());
        Console.WriteLine(Sum(a1, b1));
        static int Sum(int a, int b) => a + b;

        //5.2
        Console.Write("����� = "); int n2 = int.Parse(Console.ReadLine());
        Console.WriteLine(IsEven(n2));
        static bool IsEven(int n) => n % 2 == 0;

        //5.3
        Console.Write("n = "); int n3 = int.Parse(Console.ReadLine());
        Console.WriteLine(Factorial(n3));
        //5.3
        static long Factorial(int n)
        {
            if (n == 0) return 1;
            long res = 1;
            for (int i = 2; i <= n; i++) res *= i;
            return res;
        }

        //5.4
        Greeting();
        Greeting("�������");
        Greeting("����", "������ ����");
        static void Greeting(string name = "�����", string message = "������")
        => Console.WriteLine($"{message}, {name}!");

        //5.5
        int[] arr5 = { 7, 3, 9, 1, 6 };
        Console.WriteLine(MaxInArray(arr5));
        static int MaxInArray(int[] arr)
        {
            int max = arr[0];
            for (int i = 1; i < arr.Length; i++)
                if (arr[i] > max) max = arr[i];
            return max;
        }

        //5.6
        Console.WriteLine(Power(2, 4));
        Console.WriteLine(Power(2.5, 3));
        static int Power(int a, int b)
        {
            int res = 1;
            for (int i = 0; i < b; i++) res *= a;
            return res;
        }
        static double Power(double a, int b)
        {
            double res = 1;
            for (int i = 0; i < b; i++) res *= a;
            return res;
        }

        //5.7
        int val = 15;
        MultiplyByTwo(ref val);
        Console.WriteLine(val);
        static void MultiplyByTwo(ref int x) => x *= 2;


        //5.9
        int[] arr9 = { 64, 34, 25, 12, 22, 11, 90 };
        BubbleSort(arr9);
        Console.WriteLine(string.Join(" ", arr9));
        static void BubbleSort(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
                for (int j = 0; j < arr.Length - i - 1; j++)
                    if (arr[j] > arr[j + 1])
                    {
                        int t = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = t;
                    }
        }
        //5.10
        Console.Write("������ = "); string str = Console.ReadLine();
        Console.WriteLine(IsPalindrome(str));
        static bool IsPalindrome(string s)
        {
            s = new string(s.Where(char.IsLetterOrDigit).ToArray()).ToLower();
            for (int i = 0; i < s.Length / 2; i++)
                if (s[i] != s[s.Length - 1 - i])
                    return false;
            return true;
        }

        //5.11
        Console.WriteLine(SumAll(1, 2, 3, 4, 5));
        Console.WriteLine(SumAll(10, 20));
        static int SumAll(params int[] nums)
        {
            int sum = 0;
            foreach (int n in nums) sum += n;
            return sum;
        }
    }

}
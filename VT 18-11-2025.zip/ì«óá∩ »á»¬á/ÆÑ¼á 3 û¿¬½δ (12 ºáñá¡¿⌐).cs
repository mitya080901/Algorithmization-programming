using System;

class Program
{
    static void Main()
    {
        //3.1
        Console.Write("N = ");
        int n1 = Convert.ToInt32(Console.ReadLine());
        for (int i = 1; i <= n1; i++)
            Console.Write(i + " ");
        Console.WriteLine();

        //3.2
        Console.Write("N = ");
        int n2 = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        for (int i = 1; i <= n2; i++)
            sum += i;
        Console.WriteLine(sum);

        //3.3
        Console.WriteLine("������� ��������� 1-9:");
        for (int i = 1; i <= 9; i++)
        {
            for (int j = 1; j <= 9; j++)
                Console.Write($"{i}*{j}={i * j}\t");
            Console.WriteLine();
        }

        //3.4
        Console.Write("N = ");
        int n4 = Convert.ToInt32(Console.ReadLine());
        long fact = 1;
        for (int i = 1; i <= n4; i++)
            fact *= i;
        Console.WriteLine(fact);

        //3.5
        Console.Write("������� ����� ��������� �������? ");
        int n5 = Convert.ToInt32(Console.ReadLine());
        int a = 0, b = 1;
        for (int i = 0; i < n5; i++)
        {
            Console.Write(a + " ");
            int temp = a + b;
            a = b;
            b = temp;
        }
        Console.WriteLine();

        //3.6
        Console.Write("������� �����: ");
        int num = Convert.ToInt32(Console.ReadLine());
        bool prime = true;
        for (int i = 2; i * i <= num; i++)
        {
            if (num % i == 0)
            {
                prime = false;
                break;
            }
        }
        Console.WriteLine(prime && num > 1 ? "�������" : "���������");

        //3.7
        Console.Write("������� �����: ");
        int number = Convert.ToInt32(Console.ReadLine());
        int reversed = 0;
        while (number > 0)
        {
            reversed = reversed * 10 + number % 10;
            number /= 10;
        }
        Console.WriteLine(reversed);

        //3.8
        Console.Write("������� �����: ");
        int num8 = Convert.ToInt32(Console.ReadLine());
        int digitSum = 0;
        while (num8 > 0)
        {
            digitSum += num8 % 10;
            num8 /= 10;
        }
        Console.WriteLine(digitSum);

        //3.9
        Console.Write("�� ������ ����� �������� �������? ");
        int limit = Convert.ToInt32(Console.ReadLine());
        for (int i = 2; i <= limit; i++)
        {
            bool isPrime = true;
            for (int j = 2; j * j <= i; j++)
            {
                if (i % j == 0)
                {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) Console.Write(i + " ");
        }
        Console.WriteLine();

        //3.10
        Random rnd = new Random();
        int secret = rnd.Next(1, 101);
        int guess = 0;
        while (guess != secret)
        {
            Console.Write("�������� ����� (1-100): ");
            guess = Convert.ToInt32(Console.ReadLine());
            if (guess < secret) Console.WriteLine("������");
            else if (guess > secret) Console.WriteLine("������");
        }
        Console.WriteLine("�������!");

        //3.11
        Console.Write("������ ��������: ");
        int h = Convert.ToInt32(Console.ReadLine());
        for (int i = 1; i <= h; i++)
        {
            for (int j = 0; j < h - i; j++) Console.Write(" ");
            for (int j = 0; j < i * 2 - 1; j++) Console.Write("*");
            Console.WriteLine();
        }

        //3.12
        Console.Write("a = ");
        int a12 = Convert.ToInt32(Console.ReadLine());
        Console.Write("b = ");
        int b12 = Convert.ToInt32(Console.ReadLine());
        while (b12 != 0)
        {
            int temp = b12;
            b12 = a12 % b12;
            a12 = temp;
        }
        Console.WriteLine(a12);
    }
}
using System;

class Program
{
    static void Main()
    {
        Random rnd = new Random();

        //4.1
        int[] arr1 = new int[10];
        for (int i = 0; i < arr1.Length; i++)
            arr1[i] = rnd.Next(1, 100);
        foreach (int x in arr1) Console.Write(x + " ");
        Console.WriteLine();

        //4.2
        int[] arr2 = { 5, 12, 3, 8, 19 };
        int sum = 0;
        foreach (int x in arr2) sum += x;
        Console.WriteLine(sum);

        //4.3
        int[] arr3 = { 4, 17, 8, 23, 11 };
        int max = arr3[0];
        int idx = 0;
        for (int i = 1; i < arr3.Length; i++)
            if (arr3[i] > max)
            {
                max = arr3[i];
                idx = i;
            }
        Console.WriteLine($"max = {max}, index = {idx}");

        //4.4
        int[] arr4 = { 1, 2, 3, 4, 5 };
        Array.Reverse(arr4);
        foreach (int x in arr4) Console.Write(x + " ");
        Console.WriteLine();

        //4.5
        int[] arr5 = { 10, 20, 30, 40, 50 };
        Console.Write("��� ����? ");
        int target = Convert.ToInt32(Console.ReadLine());
        int pos = -1;
        for (int i = 0; i < arr5.Length; i++)
            if (arr5[i] == target)
            {
                pos = i;
                break;
            }
        Console.WriteLine(pos >= 0 ? $"������� �� ������� {pos}" : "�� �������");

        //4.6
        int[] arr6 = { 3, 8, 12, 7, 15, 4 };
        int even = 0, odd = 0;
        foreach (int x in arr6)
            if (x % 2 == 0) even++;
            else odd++;
        Console.WriteLine($"������: {even}, ��������: {odd}");

        //4.7
        int[] arr7 = { 64, 34, 25, 12, 22, 11, 90 };
        for (int i = 0; i < arr7.Length - 1; i++)
            for (int j = 0; j < arr7.Length - 1 - i; j++)
                if (arr7[j] > arr7[j + 1])
                {
                    int t = arr7[j];
                    arr7[j] = arr7[j + 1];
                    arr7[j + 1] = t;
                }
        foreach (int x in arr7) Console.Write(x + " ");
        Console.WriteLine();

        //4.8
        int[,] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
                Console.Write(matrix[i, j] + " ");
            Console.WriteLine();
        }

        //4.9
        int[,] m2 = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        int diagSum = 0;
        for (int i = 0; i < m2.GetLength(0); i++)
            diagSum += m2[i, i];
        Console.WriteLine(diagSum);

        //4.10
        int[][] jagged = new int[4][];
        jagged[0] = new int[] { 1, 2 };
        jagged[1] = new int[] { 3, 4, 5 };
        jagged[2] = new int[] { 6 };
        jagged[3] = new int[] { 7, 8, 9, 10 };
        for (int i = 0; i < jagged.Length; i++)
        {
            for (int j = 0; j < jagged[i].Length; j++)
                Console.Write(jagged[i][j] + " ");
            Console.WriteLine();
        }

        //4.11
        int[,] orig = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        int[,] trans = new int[3, 3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                trans[i, j] = orig[j, i];
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
                Console.Write(trans[i, j] + " ");
            Console.WriteLine();
        }

        //4.12
        int[] a1 = { 1, 3, 5, 7 };
        int[] a2 = { 2, 4, 6, 8, 9 };
        int[] merged = new int[a1.Length + a2.Length];
        int p1 = 0, p2 = 0, k = 0;
        while (p1 < a1.Length && p2 < a2.Length)
        {
            if (a1[p1] <= a2[p2])
                merged[k++] = a1[p1++];
            else
                merged[k++] = a2[p2++];
        }
        while (p1 < a1.Length) merged[k++] = a1[p1++];
        while (p2 < a2.Length) merged[k++] = a2[p2++];
        foreach (int x in merged) Console.Write(x + " ");
        Console.WriteLine();
    }
}